package com.example.UserService.service;

import com.example.UserService.Exception.UserAlreadyExistsException;
import com.example.UserService.Exception.UserNotFoundException;
import com.example.UserService.model.User;

public interface UserService {
    User saveUser(User user) throws UserAlreadyExistsException;

    User findBy(User user) throws UserNotFoundException;
}
