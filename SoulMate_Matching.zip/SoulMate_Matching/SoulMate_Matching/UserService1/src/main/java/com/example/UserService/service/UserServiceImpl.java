package com.example.UserService.service;


import com.example.UserService.Exception.UserAlreadyExistsException;
import com.example.UserService.Exception.UserNotFoundException;
import com.example.UserService.model.User;
import com.example.UserService.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.net.SocketOption;

@Service
public class UserServiceImpl implements UserService {

    private UserRepository userRepository;


    @Autowired
    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public User saveUser(User user) throws UserAlreadyExistsException {
        if(userRepository.findByEmail(user.getEmail()).isPresent())
            throw  new UserAlreadyExistsException();
        return userRepository.save(user);
    }
    @Override
    public User findBy(User user) throws UserNotFoundException {
        System.out.println("userr");
        System.out.println(userRepository.findByEmail(user.getEmail()).get());
        if(userRepository.findByEmail(user.getEmail()).isEmpty()) {
            throw new UserNotFoundException();
        }
        System.out.println("----------");
       System.out.println(userRepository.findByEmailAndPassword(user.getEmail(),user.getPassword()));
      return userRepository.findByEmailAndPassword(user.getEmail(),user.getPassword());
    }


}
