package com.example.UserService.config;


import com.example.UserService.DTO.userDTO;
import com.example.UserService.Exception.UserAlreadyExistsException;
import com.example.UserService.model.User;
import com.example.UserService.service.UserService;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Random;

@Component
public class Consumer {
    @Autowired
    private UserService userService;
    private int id;

    @RabbitListener(queues = "userQueue")
    public void getData(userDTO userDTO) throws UserAlreadyExistsException {

        User user = new User();
        user.setEmail(userDTO.getEmail());
//        user.setName(userDTO.getName());
//        user.setCity(userDTO.getCity());
//        user.setAge(userDTO.getAge());
//        user.setGender(user.getGender());
        user.setPassword(userDTO.getPassword());
//        user.setId(rand.nextInt(10000));
        userService.saveUser(user);
    }
}
