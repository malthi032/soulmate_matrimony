package com.example.UserService.DTO;

import lombok.Data;

@Data
public class userDTO {
    String email;
    String password;
//    String name;
//    String city;
//    String gender;
//    int age;

}
