package com.example.UserService.service;

import com.example.UserService.model.User;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Service
public class GenerateTokenImpl implements GenerateToken {

    @Override
    public Map<String,String> generateToken(User user) {
        System.out.println("gentoken");
            String jwttoken= Jwts.builder().setSubject(String.valueOf(user.getEmail()))
                    .setIssuedAt(new Date())
                    .signWith(SignatureAlgorithm.HS256,"secretkey").compact();
            System.out.println(jwttoken);
            Map<String,String> map=new HashMap<>();
            map.put("token",jwttoken);
            map.put("message","Logged in Successfully");
            return map;
        }
    }

