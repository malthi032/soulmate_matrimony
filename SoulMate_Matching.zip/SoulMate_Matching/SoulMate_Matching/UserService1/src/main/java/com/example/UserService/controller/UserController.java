package com.example.UserService.controller;

import com.example.UserService.Exception.UserAlreadyExistsException;
import com.example.UserService.Exception.UserNotFoundException;
import com.example.UserService.model.User;
import com.example.UserService.service.GenerateToken;
import com.example.UserService.service.GenerateTokenImpl;
import com.example.UserService.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;


@RestController
@RequestMapping("/api/user")
@CrossOrigin("http://localhost:4200/")
public class UserController {
   private UserService userService;
   private GenerateToken securityTokenGenerator;

   @Autowired
    public UserController(UserService userService,GenerateToken securityTokenGenerator) {
        this.userService = userService;
       this.securityTokenGenerator=securityTokenGenerator;
    }

    @PostMapping("/user")
    public  ResponseEntity<?> save(@RequestBody User user) throws UserAlreadyExistsException {
       return new ResponseEntity<>(userService.saveUser(user),HttpStatus.CREATED);
    }

    @PostMapping("/login")
    public String login(@RequestBody User user) throws UserNotFoundException {
        Map<String,String> map=null;
        try{
            User user1 = userService.findBy(user);
            System.out.println("controller");
            System.out.println(user1);
            if(user1.getEmail().equalsIgnoreCase(user.getEmail())) {
                System.out.println("emaill");
                map= securityTokenGenerator.generateToken(user1);
            }
            //return new ResponseEntity(map,HttpStatus.OK);
            return map.get("token");
        }
        catch (Exception e) {
            //return new ResponseEntity("try after some time",HttpStatus.INTERNAL_SERVER_ERROR);
            System.out.println(e.toString());
            //return new ResponseEntity("try after some time",HttpStatus.INTERNAL_SERVER_ERROR);
            return "try after some time";
        }
    }

    @GetMapping("/dis")
    public void display(){
       System.out.println("hello");
    }

}
