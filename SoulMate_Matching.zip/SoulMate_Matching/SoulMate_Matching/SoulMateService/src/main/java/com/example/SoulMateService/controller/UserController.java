package com.example.SoulMateService.controller;

import com.example.SoulMateService.DTO.UserDTO;
import com.example.SoulMateService.model.User;
import com.example.SoulMateService.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@RestController
@RequestMapping("/api/soulmate")
@CrossOrigin("http://localhost:4200/")
public class UserController {


    private UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody UserDTO userDTO) throws IOException {
        //System.out.println("Original Image Byte Size - " + userDTO.getImgUrl().getBytes().length);
        return new ResponseEntity(userService.register(userDTO), HttpStatus.CREATED);
    }

    @PostMapping("/upload")
    public void uplaodImage(@RequestParam("imageFile") MultipartFile file) throws IOException {
        System.out.println("Original Image Byte Size - " + file.getBytes().length);
        userService.registerImage(file);
    }

    @PostMapping("/getUser")
    public User getUser(@RequestBody String email){
      return userService.getUser(email);
    }

    @RequestMapping(value = "/get", method = RequestMethod.GET)
    public ResponseEntity<?> getUsers(){
        return new ResponseEntity(userService.getAllUsers(), HttpStatus.OK);
    }

}
