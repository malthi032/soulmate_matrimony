package com.example.SoulMateService.config;

import com.example.SoulMateService.DTO.UserDTO;
import com.example.SoulMateService.model.User;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Producer {


    private DirectExchange directExchange;
    private RabbitTemplate rabbitTemplate;

    @Autowired
    public Producer(DirectExchange directExchange, RabbitTemplate rabbitTemplate) {
        this.directExchange = directExchange;
        this.rabbitTemplate = rabbitTemplate;
    }

    public void sendMessage(UserDTO userDTO){
       rabbitTemplate.convertAndSend(directExchange.getName(),"user_routing",userDTO);
      // rabbitTemplate.convertAndSend(directExchange.getName(),"matching_routing",userDTO);
    }

    public void sendMessageToRabbitMq1(User user)
    {
        rabbitTemplate.convertAndSend(directExchange.getName(),"matching_routing",user);
    }

}
