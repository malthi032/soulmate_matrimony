package com.example.SoulMateService.service;

import com.example.SoulMateService.DTO.UserDTO;
import com.example.SoulMateService.config.Producer;
import com.example.SoulMateService.model.ImageModel;
import com.example.SoulMateService.model.User;
import com.example.SoulMateService.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.aggregation.ConvertOperators;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.zip.Deflater;
import java.util.zip.Inflater;


@Service
public class UserServiceImpl implements UserService{


    private UserRepository userRepository;
    private Producer producer;
    private User user1 = new User();
    private UserDTO userDTO1 = new UserDTO();

    @Autowired
    public UserServiceImpl(UserRepository userRepository, Producer producer) {
        this.userRepository = userRepository;
        this.producer = producer;
    }

    @Override
    public User register(UserDTO userDTO) throws IOException {
        System.out.println("-------------------register--------------");
       User user = new User();
       user.setName(userDTO.getName());
       user.setAge(userDTO.getAge());
       user.setCity(userDTO.getCity());
       user.setEmail(userDTO.getEmail());
       user.setGender(userDTO.getGender());
       System.out.println(user);
        System.out.println("save user11");
        user1 = user;
        userDTO1 = userDTO;
        System.out.println(user1);
        //producer.sendMessageToRabbitMq1(user1);
       return user;
    }

    @Override
    public void registerImage(MultipartFile file) throws IOException{
//        System.out.println("imgService");
//        System.out.println(userDTO1);
        ImageModel img = new ImageModel(file.getOriginalFilename(), file.getContentType(),
                compressBytes(file.getBytes()));
        if(user1!=null){
            user1.setImg(img);
            userRepository.save(user1);
            System.out.println(user1);
            producer.sendMessage(userDTO1);
            producer.sendMessageToRabbitMq1(user1);
            user1 = null;
            userDTO1 = null;
        }
    }

    @Override
    public User getUser(String email){
        return userRepository.findByEmail(email);
    }
    @Override
    public List<User> getAllUsers(){
        List<User> userList = userRepository.findByName("Kou6");
        List<User> userList1 = (List<User>) userRepository.findAll();
        System.out.println(userList1);
        for (User user:userList1){
            ImageModel img = new ImageModel(user.getImg().getName(), user.getImg().getType(),
                    decompressBytes(user.getImg().getPicByte()));
            user.setImg(img);
            System.out.println(user);
        }
        return userList1;
    }

    public static byte[] decompressBytes(byte[] data) {
        Inflater inflater = new Inflater();
        inflater.setInput(data);
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream(data.length);
        byte[] buffer = new byte[1024];
        try {
            while (!inflater.finished()) {
                int count = inflater.inflate(buffer);
                outputStream.write(buffer, 0, count);
            }
            outputStream.close();
        } catch (Exception e) {
        }
        return outputStream.toByteArray();
    }

    public static byte[] compressBytes(byte[] data) {
        Deflater deflater = new Deflater();
        deflater.setInput(data);
        deflater.finish();
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream(data.length);
        byte[] buffer = new byte[1024];
        while (!deflater.finished()) {
            int count = deflater.deflate(buffer);
            outputStream.write(buffer, 0, count);
        }
        try {
            outputStream.close();
        } catch (IOException e) {
        }
        System.out.println("Compressed Image Byte Size - " + outputStream.toByteArray().length);
        return outputStream.toByteArray();
    }

}
