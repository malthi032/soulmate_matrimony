package com.example.SoulMateService;


import com.example.SoulMateService.filter.Jwtfilter;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@SpringBootApplication
public class SoulMateServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoulMateServiceApplication.class, args);
	}

	@Bean
	FilterRegistrationBean jwtFilter(){
		FilterRegistrationBean filterRegistrationBean=new FilterRegistrationBean();
		filterRegistrationBean.setFilter(new Jwtfilter());
		filterRegistrationBean.addUrlPatterns("/api/soulmate/get/user");
		return filterRegistrationBean;
	}

}
