package com.example.SoulMateService.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.io.File;

@Data
@Document
public class User {
    String name;
    String email;
    String city;
    String gender;
    int age;
    ImageModel img;
}
