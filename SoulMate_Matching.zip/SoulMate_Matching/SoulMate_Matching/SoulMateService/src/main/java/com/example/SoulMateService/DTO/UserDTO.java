package com.example.SoulMateService.DTO;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.bson.json.JsonObject;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;

@Data
public class UserDTO {
    String name;
    String email;
    String city;
    String gender;
    int age;
    String password;
    //MultipartFile imgUrl;

}
