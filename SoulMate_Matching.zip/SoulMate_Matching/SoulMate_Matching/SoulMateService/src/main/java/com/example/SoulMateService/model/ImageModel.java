package com.example.SoulMateService.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ImageModel {

    private String name;
    private String type;
    private byte[] picByte;
    //private String base64String;
}
