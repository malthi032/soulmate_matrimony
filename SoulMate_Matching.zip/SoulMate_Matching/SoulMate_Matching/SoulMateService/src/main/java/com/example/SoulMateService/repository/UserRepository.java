package com.example.SoulMateService.repository;

import com.example.SoulMateService.model.User;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserRepository extends CrudRepository<User,String> {
    User findByEmail(String originalFilename);

    List<User> findByName(String name);
}
