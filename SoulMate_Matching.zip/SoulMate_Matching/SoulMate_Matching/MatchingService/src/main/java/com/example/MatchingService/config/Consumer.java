package com.example.MatchingService.config;

import com.example.MatchingService.Model.User;
import com.example.MatchingService.service.MatchingService;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Consumer {

    @Autowired
    private MatchingService userService;

    @RabbitListener(queues = "matching_queue")
    public void getData(User user) {
        System.out.println("hello");
        userService.saveUser(user);
    }
}
