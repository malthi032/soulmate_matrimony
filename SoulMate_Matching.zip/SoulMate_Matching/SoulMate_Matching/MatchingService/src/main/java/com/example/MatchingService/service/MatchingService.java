package com.example.MatchingService.service;

import com.example.MatchingService.Model.User;

public interface MatchingService {
    User createUserNode(User user1, User user2);

    void createRelation(String user1, String user2);

    User saveUser(User user);

    void getAllRelations(String email);
}
