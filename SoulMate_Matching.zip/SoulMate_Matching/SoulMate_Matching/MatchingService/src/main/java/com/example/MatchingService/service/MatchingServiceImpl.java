package com.example.MatchingService.service;

import com.example.MatchingService.Model.User;
import com.example.MatchingService.repository.MatchingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MatchingServiceImpl implements MatchingService{
    private MatchingRepository userRepository;

    @Autowired
    public MatchingServiceImpl(MatchingRepository matchingRepository) {
        this.userRepository = matchingRepository;
    }

    @Override
    public User createUserNode(User user1, User user2) {

//        User user1 = userRepository.findUserByEmail(email1).get();
//        User user2 = userRepository.findUserByEmail(email2).get();
        createRelation(user1.getEmail(),user2.getEmail());
//        if(userRepository.findUserByEmail(user1.getEmail()).isPresent()&&(userRepository.findUserByEmail(user2.getEmail())).isPresent()){
//            System.out.println("Both Present");
//            createRelation(user1.getEmail(),user2.getEmail());
//        }
//        else if(userRepository.findUserByEmail(user1.getEmail()).isEmpty()&&(userRepository.findUserByEmail(user2.getEmail())).isEmpty()){
//            System.out.println(
//                    userRepository.save(user1));
////          userRepository.save(user1);
//            userRepository.save(user2);
//            System.out.println("Both Not Present");
//            createRelation(user1.getEmail(),user2.getEmail());
//        }
//        else if(userRepository.findUserByEmail(user1.getEmail()).isEmpty()){
//            userRepository.save(user1);
//            createRelation(user1.getEmail(),user2.getEmail());
//        }
//        else {
//            userRepository.save(user2);
//            createRelation(user1.getEmail(),user2.getEmail());
//        }
        return user2;
    }

    @Override
    public void createRelation(String user1, String user2){
        System.out.println(user1+"  "+user2);
        userRepository.createRelationship(user1,user2);
    }

    @Override
    public User saveUser(User user){
        return userRepository.save(user);
    }

    @Override
    public void getAllRelations(String email){
       // System.out.println(userRepository.getallRelations(email));
    }
}
