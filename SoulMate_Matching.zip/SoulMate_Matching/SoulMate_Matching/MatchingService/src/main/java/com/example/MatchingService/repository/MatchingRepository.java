package com.example.MatchingService.repository;

import com.example.MatchingService.Model.User;
import org.neo4j.ogm.metadata.schema.Node;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.data.neo4j.repository.query.Query;


import java.sql.Array;
import java.util.Optional;

public interface MatchingRepository extends Neo4jRepository<User,Long> {

    @Query("MATCH(u:User {email:$email}) RETURN u")
    Optional<User> findUserByEmail(String email);

    @Query("MATCH(u:User {email:$email}),(u1:User {email:$email1}) CREATE(u)-[:from]->(u1)")
    void createRelationship(String email, String email1);

//    @Query("MATCH (u1:User {email: $email})-[r]-() RETURN u1")
//    Array getallRelations(String email);
}
