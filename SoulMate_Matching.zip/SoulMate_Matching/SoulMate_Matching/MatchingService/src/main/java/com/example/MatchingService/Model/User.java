package com.example.MatchingService.Model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import org.neo4j.ogm.annotation.NodeEntity;
import org.springframework.data.annotation.Id;
import org.springframework.data.neo4j.core.schema.GeneratedValue;


@NodeEntity
@AllArgsConstructor
@Data
public class User {
        @Id
        @GeneratedValue
        private Long id;
        private String name;
        private String email;
        private String city;
        private int age;
        private String gender;

        public User() {
        }
}

