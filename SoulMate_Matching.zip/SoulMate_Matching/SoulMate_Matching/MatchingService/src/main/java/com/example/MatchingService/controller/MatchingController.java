package com.example.MatchingService.controller;

import com.example.MatchingService.Model.User;
import com.example.MatchingService.service.MatchingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("api/v1/recommend")
@CrossOrigin("http://localhost:4200/")
public class MatchingController {

    private MatchingService matchingService;

    @Autowired
    public MatchingController(MatchingService matchingService) {
        this.matchingService = matchingService;
    }
    @PostMapping("/user")
    public ResponseEntity<?> createUser(@RequestBody Map<String, User> user) {
        System.out.println("--------");
        System.out.println(user.get("user1"));
        System.out.println(user.get("user2"));
        return new ResponseEntity<>(matchingService.createUserNode(user.get("user1"),user.get("user2")), HttpStatus.CREATED);
    }

    @PostMapping("/relations")
    public void getAllRelations(@RequestBody String email){
        matchingService.getAllRelations(email);
    }
}
