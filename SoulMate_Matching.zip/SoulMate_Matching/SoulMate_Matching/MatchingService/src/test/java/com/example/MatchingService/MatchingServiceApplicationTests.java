package com.example.MatchingService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MatchingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
