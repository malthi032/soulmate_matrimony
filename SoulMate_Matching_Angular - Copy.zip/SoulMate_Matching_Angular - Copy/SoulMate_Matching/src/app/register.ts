export class register{
    name:string="";
    email:string="";
    age:number=0;
    gender:string="";
    city:string="";
    password:any;
    imgUrl:any;

    constructor(){
        this.name="";
       this.email="",
       this.age=0,
       this.city="",
       this.gender="",
       this.password=""
       this.imgUrl=""
    }
}