import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { NavComponent } from './nav/nav.component';
import { userdata } from './userdata';

@Injectable({
  providedIn: 'root'
})
export class SoulmateService {

  constructor(private httpClient:HttpClient) { }

  loginUserId:string="";
  user:any;
  loginUser:any;
  token:any="";
  viewUser:any;
  myprofile:any="";

 generatetoken(){
   return this.httpClient.get('http://localhost:8085/api/user/login')
 }

 authenticate(){
  let tokenstr = 'Bearer '+this.token;
  const headers = new HttpHeaders().set('authorization',tokenstr);
  return this.httpClient.get('http://localhost:8084/api/soulmate/get',{headers});
 }

 getLoginUser(email:string){
   return this.httpClient.post('http://localhost:8084/api/soulmate/getUser',email);
 }

 getLoginUser1(email:string){
    this.httpClient.post('http://localhost:8084/api/soulmate/getUser',email).subscribe(data => {
       this.loginUser = data;
       this.user=data;
    });
}
}
