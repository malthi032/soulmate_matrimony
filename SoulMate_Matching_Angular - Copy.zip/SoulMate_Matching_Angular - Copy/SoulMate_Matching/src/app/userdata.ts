export class userdata{
    name:string="";
    email:string="";
    age:number=0;
    gender:string="";
    city:string="";
    retImg:any;

    constructor(){
        this.name="";
       this.email="",
       this.age=0,
       this.city="",
       this.gender="",
       this.retImg="";
    }

}