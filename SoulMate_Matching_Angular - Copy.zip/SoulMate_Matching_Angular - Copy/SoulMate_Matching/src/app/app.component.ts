import { Component } from '@angular/core';
import { SoulmateService } from './soulmate.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'SoulMate_Matching';


  constructor(private service:SoulmateService){
    // console.log("apppp")
    // console.log(this.service.getLoginUser(this.service.loginUserId));
  }
}
