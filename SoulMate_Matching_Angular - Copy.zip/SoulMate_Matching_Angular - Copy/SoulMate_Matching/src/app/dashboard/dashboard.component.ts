import { HttpBackend, HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { register } from '../register';
import { SoulmateService } from '../soulmate.service';
import { userdata } from '../userdata';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  retrieveResonse:any=[];
  data:any=[];
  userData:any[]=[];
  base64Data:any;
  retrievedImage:any=[];
  img:string="";
  loginUser:any="";
  user = new userdata();


  constructor(private httpClient:HttpClient,private service:SoulmateService,private fb:FormBuilder) {  
   }

  ngOnInit(): void {
    this.loginUser=sessionStorage.getItem("user");
    this.userData.length=0;
    this.retrievedImage.length=0;
    this.data.length=0;
    console.log(this.data.length);
    this.retrievedImage.length=0;
  
       this.display();
      this.service.getLoginUser(this.service.loginUserId).subscribe(value => {
        console.log("loginUser");
        this.loginUser=value;
        console.log(value);
      })
  }

  display(){
    this.service.authenticate()
    .subscribe(
      res => {
        // this.retrieveResonse.push(res);
        this.data.push(res);
        console.log("response length");
        console.log(this.data[0].length);
       // console.log(this.data[0]);
        console.log("image Response")

        for (let index = 0; index < this.data[0].length; index++) {
         const user = new userdata();
         if(this.data[0][index].email==this.service.loginUserId)
         {
          user.name=this.data[0][index].name;
          user.age=this.data[0][index].age;
          user.city=this.data[0][index].city;
          user.gender=this.data[0][index].gender;
          user.email=this.data[0][index].email;
         this.base64Data=this.data[0][index].img.picByte;
         user.retImg = 'data:image/jpeg;base64,' + this.base64Data;
         this.service.myprofile=user;
         }
         else{
          user.name=this.data[0][index].name;
          user.age=this.data[0][index].age;
          user.city=this.data[0][index].city;
          user.gender=this.data[0][index].gender;
          user.email=this.data[0][index].email;
         this.base64Data=this.data[0][index].img.picByte;
        // this.retrievedImage.push('data:image/jpeg;base64,' + this.base64Data);
         user.retImg = 'data:image/jpeg;base64,' + this.base64Data;
         this.userData.push(user);
         console.log("user");
         }
       
         // console.log(this.retrievedImage[0]);
        }
        console.log(this.userData);
      });
  }
searchUser(name:any,value:string){
  const data = this.userData;
   console.log(this.userData.filter(e => e.name==name));
   let search = this.userData.filter(e => e.name==name);
   if(this.userData.filter(e => e.name!=name))
   {
     console.log(value);
   }
   if(search!=null)
   {
    console.log(value);
     this.userData.length=0;
     this.userData.push(search[0]);
   }
   if (name=="" || name==" "){
      this.userData.length=0;
      this.userData.push(data);
       this.display();
   }
}


viewUser(data:any){
  console.log("---------------------------------------------------")
  console.log("viewUser");
  console.log(data)
  console.log("loginUser");
  console.log(this.loginUser);
  this.service.viewUser=data;
}

}
