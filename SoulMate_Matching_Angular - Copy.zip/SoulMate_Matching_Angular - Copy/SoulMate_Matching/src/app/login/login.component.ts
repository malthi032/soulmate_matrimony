import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { SoulmateService } from '../soulmate.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private fb:FormBuilder,private httpClient:HttpClient,private service:SoulmateService,private router:Router) { }

  ngOnInit(): void {
  }
  
  captcha:any=" ";
  token:any="";
  split1:any="hello";

  registerForm = this.fb.group({
    email:"",
    password:""
   });
   error:string="";

   getcaptcha(){
      let email = this.registerForm.controls['email'].value;
      let password = this.registerForm.controls['password'].value;
      let login = {"email":email,"password":password};
      console.log(login);
      this.httpClient.post("http://localhost:8085/api/user/login",login,{responseType:'text' as 'json'}).subscribe((value)=>{
        console.log(value);
        if(value!='try after some time'){
          this.error="";
          this.service.token=value;
        let token = this.service.token;
        let split1 = token.substring(token.length-5);
        this.split1=split1;
        //this.captcha= split1.charAt(0)+"  "+split1.charAt(1)+"  "+split1.charAt(2)+"  "+split1.charAt(3)+"  "+split1.charAt(4);
        this.token= split1.charAt(0)+"  "+split1.charAt(1)+"  "+split1.charAt(2)+"  "+split1.charAt(3)+"  "+split1.charAt(4);
        console.log(this.captcha)

          this.service.loginUserId=email;
          this.service.getLoginUser1(email);
          sessionStorage.setItem("user",this.service.loginUser);
          //this.route.navigate(['/search']);
        }
        else{
          this.error="*Invalid credentials";
        }
  });
}

login(captcha:any){
    if(captcha==this.split1)
    {
      this.router.navigate(['/cards']);
      console.log("matches");
    }
}

getUser(){
  return this.service.loginUser;
}
}
