import { TestBed } from '@angular/core/testing';

import { SoulmateService } from './soulmate.service';

describe('SoulmateService', () => {
  let service: SoulmateService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SoulmateService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
