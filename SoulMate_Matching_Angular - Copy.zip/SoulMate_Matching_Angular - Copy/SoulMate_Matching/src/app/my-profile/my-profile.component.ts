import { Component, OnInit } from '@angular/core';
import { SoulmateService } from '../soulmate.service';
import { userdata } from '../userdata';

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.css']
})
export class MyProfileComponent implements OnInit {

  constructor(private service:SoulmateService) { }

  data:any;
  data1:any;
  img:any="";
  ngOnInit(): void {
    this.data1=this.service.myprofile;
    console.log(this.data1.retImg);
    
  }

}
