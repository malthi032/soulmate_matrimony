import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { DomSanitizer, SafeResourceUrl, SafeUrl, SafeValue } from '@angular/platform-browser';
import { Observable, ReplaySubject } from 'rxjs';
import { register } from '../register';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private fb:FormBuilder,private httpClinent:HttpClient,private _sanitizer: DomSanitizer) { }

  ngOnInit(): void {
  }
  
  registerForm = this.fb.group({
   name:"",
   email:"",
   age:"",
   city:"",
   gender:"",
   password:"",
  });
  
  reg = new register();
  
  message:any;
  imagePath:any;
  url:any;
  
  upimage:any;
  onFileChanged(event:any) {
    const files = event.target.files;
    this.upimage = event.target.files[0];
    if (files.length === 0)
        return;

    const mimeType = files[0].type;
    if (mimeType.match(/image\/*/) == null) {
        this.message = "Only images are supported.";
        return;
    }

    const reader = new FileReader();
    this.imagePath = files;
    reader.readAsDataURL(files[0]); 
    reader.onload = (_event) => { 
        this.url = reader.result; 
    }
}

  async register(img:any){
     console.log(this.registerForm);
     console.log(img);
     this.reg.name=this.registerForm.controls['name'].value;
     this.reg.age=this.registerForm.controls['age'].value;
     this.reg.city=this.registerForm.controls['city'].value;
     this.reg.gender=this.registerForm.controls['gender'].value;
     this.reg.email=this.registerForm.controls['email'].value;
     this.reg.password=this.registerForm.controls['password'].value;
     
    const uploadImageData = new FormData();
    //this.upimage.name = this.reg.email;
    uploadImageData.append('imageFile', this.upimage, this.reg.email);
    console.log(uploadImageData); 
    console.log(this.reg);
     this.httpClinent.post("http://localhost:8084/api/soulmate/register",this.reg).subscribe(response=>{
      console.log(response);
  },
  
  );
  setTimeout(() => {
    this.httpClinent.post("http://localhost:8084/api/soulmate/upload",uploadImageData).subscribe((value)=>{
      console.log("-------------imagee-------------------")
      console.log(value);
  });
  }, 1000);
 
 
}

}




