import { Component, ViewChild } from '@angular/core';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';
import { SoulmateService } from '../soulmate.service';
import { LoginComponent } from '../login/login.component';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent {

  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches),
      shareReplay()
    );
  loginUser:any="";
  constructor(private breakpointObserver: BreakpointObserver,private service:SoulmateService) {
          
  }

  @ViewChild(LoginComponent)
  login!: LoginComponent;

  displayUser(){
    this.loginUser=this.service.loginUser;
    console.log("navbar");
    console.log(this.loginUser);
  }
  ngOnInit() {
    // Called after the constructor and called  after the first ngOnChanges() 
    this.loginUser=this.service.loginUser;
    console.log("navbar");
    console.log(this.loginUser);
 }

}
