import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SoulmateService } from '../soulmate.service';

@Component({
  selector: 'app-view-profile',
  templateUrl: './view-profile.component.html',
  styleUrls: ['./view-profile.component.css']
})
export class ViewProfileComponent implements OnInit {

  constructor(private activatedRoute:ActivatedRoute,private service:SoulmateService,private httpClient:HttpClient) { }

  data:any;
  ngOnInit(): void {
    this.activatedRoute.paramMap.subscribe(data => {
      let id = data.get('email') ??0;
      console.log(id);
      if(id!=0){
        console.log("hello");
       this.data = this.service.viewUser;
       console.log(this.data);
     }
     })
  }

  createRelation(){
    console.log(this.service.loginUser);
    const user = {"user1":this.data,"user2":this.service.loginUser};
     this.httpClient.post("http://localhost:8080/api/v1/recommend/user",user).subscribe( value =>{
       console.log(value);
     });
  }

}
